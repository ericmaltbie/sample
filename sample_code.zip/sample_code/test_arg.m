function test_arg(n, s)
    fprintf('n is %d\n', n);
    fprintf('s is %s\n', s);
end

